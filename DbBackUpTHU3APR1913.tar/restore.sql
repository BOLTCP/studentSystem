--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "studentSystemDb";
--
-- Name: studentSystemDb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "studentSystemDb" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "studentSystemDb" OWNER TO postgres;

\connect "studentSystemDb"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: additional_roles_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.additional_roles_enum AS ENUM (
    'club_primary_leader',
    'club_assistant_leader',
    'none',
    'laborant',
    'Клубын тэргүүн',
    'Клубын туслах тэргүүн',
    'байхгүй',
    'Лаборант'
);


ALTER TYPE public.additional_roles_enum OWNER TO postgres;

--
-- Name: announcement_options_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.announcement_options_enum AS ENUM (
    'mandatory',
    'is_not_mandatory'
);


ALTER TYPE public.announcement_options_enum OWNER TO postgres;

--
-- Name: announcement_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.announcement_status_enum AS ENUM (
    'has_read',
    'has_not_read'
);


ALTER TYPE public.announcement_status_enum OWNER TO postgres;

--
-- Name: calendar_purpose_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.calendar_purpose_enum AS ENUM (
    'important',
    'statement',
    'notification'
);


ALTER TYPE public.calendar_purpose_enum OWNER TO postgres;

--
-- Name: classroom_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.classroom_type_enum AS ENUM (
    'computer-laboratory',
    'students-dev',
    'lecture',
    'tv-classroom',
    'Компьютерийн лаборатори анги',
    'Оюутны хөгжлийн төв',
    'Лекцийн анги',
    'Семинар анги',
    'Семинар / Лекцийн анги',
    'Телевизортой анги',
    'Биеийн тамирын заал'
);


ALTER TYPE public.classroom_type_enum OWNER TO postgres;

--
-- Name: club_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.club_type_enum AS ENUM (
    'professional_club',
    'amatuer_club'
);


ALTER TYPE public.club_type_enum OWNER TO postgres;

--
-- Name: course_season_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.course_season_type_enum AS ENUM (
    'Намар, Өвөл, Хавар, Зун',
    'Намар, Өвөл, Зун',
    'Намар',
    'Хавар',
    'Намар, Хавар',
    'Өвөл, Хавар, Зун'
);


ALTER TYPE public.course_season_type_enum OWNER TO postgres;

--
-- Name: course_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.course_type_enum AS ENUM (
    'bachelors',
    'masters',
    'doctors',
    'professors',
    'Заавал судлах',
    'Сонгон судлах'
);


ALTER TYPE public.course_type_enum OWNER TO postgres;

--
-- Name: days_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.days_type_enum AS ENUM (
    'Даваа гараг',
    'Мягмар гараг',
    'Лхагва гараг',
    'Пүрэв гараг',
    'Баасан гараг',
    'Бямба гараг',
    'Ням гараг'
);


ALTER TYPE public.days_type_enum OWNER TO postgres;

--
-- Name: disabled_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.disabled_enum AS ENUM (
    'yes',
    'no',
    'Тийм',
    'Үгүй'
);


ALTER TYPE public.disabled_enum OWNER TO postgres;

--
-- Name: event_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.event_type_enum AS ENUM (
    'mandatory',
    'non-mandatory',
    'recreational',
    'outside-event'
);


ALTER TYPE public.event_type_enum OWNER TO postgres;

--
-- Name: gender_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.gender_enum AS ENUM (
    'male',
    'female',
    'other',
    'эрэгтэй',
    'эмэгтэй',
    'бусад'
);


ALTER TYPE public.gender_enum OWNER TO postgres;

--
-- Name: grade_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.grade_status_enum AS ENUM (
    'incomplete',
    'complete',
    'missing',
    'submitted',
    'other'
);


ALTER TYPE public.grade_status_enum OWNER TO postgres;

--
-- Name: invitation_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invitation_status_enum AS ENUM (
    'pending',
    'accepted',
    'denied'
);


ALTER TYPE public.invitation_status_enum OWNER TO postgres;

--
-- Name: is_active_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.is_active_enum AS ENUM (
    'is_working',
    'vacation',
    'left'
);


ALTER TYPE public.is_active_enum OWNER TO postgres;

--
-- Name: major_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.major_type_enum AS ENUM (
    'afternoon',
    'evening',
    'орой',
    'өдөр'
);


ALTER TYPE public.major_type_enum OWNER TO postgres;

--
-- Name: married_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.married_enum AS ENUM (
    'married',
    'not_married',
    'Гэрлээгүй',
    'Гэрлэсэн'
);


ALTER TYPE public.married_enum OWNER TO postgres;

--
-- Name: material_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.material_type_enum AS ENUM (
    'assignment',
    'discussion',
    'attendance_question',
    'lecture_material',
    'exam',
    'exam_entry',
    'exam_exit',
    'exam_final'
);


ALTER TYPE public.material_type_enum OWNER TO postgres;

--
-- Name: military_service_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.military_service_enum AS ENUM (
    'served',
    'not_served',
    'Тийм',
    'Үгүй',
    'Хаасан',
    'Хаагаагүй'
);


ALTER TYPE public.military_service_enum OWNER TO postgres;

--
-- Name: projector_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.projector_enum AS ENUM (
    'yes',
    'no',
    'тийм',
    'үгүй'
);


ALTER TYPE public.projector_enum OWNER TO postgres;

--
-- Name: property_category_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.property_category_enum AS ENUM (
    'offices',
    'computer',
    'office_utilities'
);


ALTER TYPE public.property_category_enum OWNER TO postgres;

--
-- Name: recieved_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.recieved_enum AS ENUM (
    'yes',
    'no'
);


ALTER TYPE public.recieved_enum OWNER TO postgres;

--
-- Name: rule_category_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.rule_category_enum AS ENUM (
    'university_academic_procedures',
    'tuition_payment_procedures',
    'laboratory_rules',
    'library_rules',
    'user_guide_canvas'
);


ALTER TYPE public.rule_category_enum OWNER TO postgres;

--
-- Name: schedule_time_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.schedule_time_type_enum AS ENUM (
    '1-р цаг',
    '2-р цаг',
    '3-р цаг',
    '4-р цаг',
    '5-р цаг',
    '6-р цаг',
    '7-р цаг',
    '8-р цаг',
    '9-р цаг'
);


ALTER TYPE public.schedule_time_type_enum OWNER TO postgres;

--
-- Name: schedule_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.schedule_type_enum AS ENUM (
    'Лекц',
    'Семинар',
    'Лаборатори'
);


ALTER TYPE public.schedule_type_enum OWNER TO postgres;

--
-- Name: sign_ups_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.sign_ups_enum AS ENUM (
    'бүртгэл хаагдсан',
    'бүртгэл нээлттэй'
);


ALTER TYPE public.sign_ups_enum OWNER TO postgres;

--
-- Name: staff_role_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.staff_role_enum AS ENUM (
    'security',
    'cleaner',
    'electrician',
    'inventory_manager',
    'manager'
);


ALTER TYPE public.staff_role_enum OWNER TO postgres;

--
-- Name: state_of_usage_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.state_of_usage_enum AS ENUM (
    'normal',
    'broken',
    'needs_service'
);


ALTER TYPE public.state_of_usage_enum OWNER TO postgres;

--
-- Name: student_attendance_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.student_attendance_enum AS ENUM (
    'arrived',
    'absent',
    'excused',
    'ill'
);


ALTER TYPE public.student_attendance_enum OWNER TO postgres;

--
-- Name: student_is_active_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.student_is_active_enum AS ENUM (
    'graduated',
    'transfered',
    'expelled',
    'studying',
    'төгссөн',
    'шилжсэн',
    'хөөгдсөн',
    'суралцаж байгаа',
    'чөлөө авсан'
);


ALTER TYPE public.student_is_active_enum OWNER TO postgres;

--
-- Name: tv_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tv_enum AS ENUM (
    'yes',
    'no',
    'тийм',
    'үгүй'
);


ALTER TYPE public.tv_enum OWNER TO postgres;

--
-- Name: type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.type_enum AS ENUM (
    'computer_science',
    'business',
    'social_studies',
    'foriegn_language',
    'administration',
    'financial',
    'admission_committee',
    'journalism'
);


ALTER TYPE public.type_enum OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'student',
    'teacher',
    'administration',
    'staff',
    'principal',
    'hr',
    'department_chair',
    'admissions_officer',
    'mental_health_counselor',
    'librarian',
    'marketing',
    'teacher_assistant'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: user_role_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role_enum AS ENUM (
    'student',
    'teacher',
    'administration',
    'staff',
    'principal',
    'hr',
    'department_chair',
    'admissions_officer',
    'mental_health_counselor',
    'librarian',
    'marketing',
    'teacher_assistant',
    'Оюутан',
    'Багш',
    'Удирдлага',
    'Ажилтан',
    'Захирал',
    'Хүний Нөөц',
    'Салбар Сургуулийн Захирал',
    'Элсэлтийн Комисс',
    'Сэтгэл Зүйч',
    'Номын Санч',
    'Маркетинг'
);


ALTER TYPE public.user_role_enum OWNER TO postgres;

--
-- Name: year_classification_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.year_classification_enum AS ENUM (
    'freshman',
    'junior',
    'sophomore',
    'senior',
    '1-р курс',
    '2-р курс',
    '3-р курс',
    '4-р курс'
);


ALTER TYPE public.year_classification_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcement (
    announcement_id integer NOT NULL,
    student_id integer NOT NULL,
    major_id integer NOT NULL,
    course_id integer NOT NULL,
    teacher_id integer NOT NULL,
    status public.announcement_status_enum NOT NULL,
    announcement jsonb NOT NULL,
    announcement_options public.announcement_options_enum DEFAULT 'mandatory'::public.announcement_options_enum NOT NULL,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.announcement OWNER TO postgres;

--
-- Name: announcement_announcement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.announcement ALTER COLUMN announcement_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.announcement_announcement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    user_id integer NOT NULL,
    login_name character varying(10) NOT NULL,
    password_hash text NOT NULL,
    profile_picture text,
    registry_number character varying(10) NOT NULL,
    user_role public.user_role_enum NOT NULL,
    fname character varying(50) NOT NULL,
    lname character varying(50) NOT NULL,
    birthday date NOT NULL,
    gender public.gender_enum NOT NULL,
    citizenship character varying(50) NOT NULL,
    state_city character varying(100) NOT NULL,
    town_district character varying(100) NOT NULL,
    valid_address character varying(100) NOT NULL,
    state_city_living character varying(100) NOT NULL,
    town_district_living character varying(100) NOT NULL,
    valid_address_living character varying(100) NOT NULL,
    postal_address character varying(50),
    home_phone_number character varying(20),
    phone_number character varying(20) NOT NULL,
    phone_number_emergency character varying(20) NOT NULL,
    country character varying(50) NOT NULL,
    ethnicity character varying(50) NOT NULL,
    social_background character varying(50) NOT NULL,
    state_city_of_birth character varying(100) NOT NULL,
    town_district_of_birth character varying(100) NOT NULL,
    place_of_birth character varying(150) NOT NULL,
    education character varying(50) NOT NULL,
    current_academic_degree character varying(50) NOT NULL,
    profession character varying(150),
    profession_certification text,
    f_passport_number character varying(50),
    married public.married_enum NOT NULL,
    military_service public.military_service_enum NOT NULL,
    pensions_established character varying(50),
    additional_notes character varying(150),
    blood_type character varying(5),
    drivers_certificate character varying(50),
    drivers_certificate_number character varying(25),
    disabled public.disabled_enum NOT NULL,
    is_active boolean DEFAULT true,
    email text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    family_tree_name character varying DEFAULT 'Халх'::character varying NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: basecurriculum; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.basecurriculum (
    base_curriculum_id integer NOT NULL,
    major_id integer NOT NULL,
    course_id integer NOT NULL,
    curriculum_year date NOT NULL,
    semester_year character(25) NOT NULL
);


ALTER TABLE public.basecurriculum OWNER TO postgres;

--
-- Name: basecurriculum_base_curriculum_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.basecurriculum ALTER COLUMN base_curriculum_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.basecurriculum_base_curriculum_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendar (
    calendar_id integer NOT NULL,
    teacher_id integer NOT NULL,
    calendar_title character varying(100) NOT NULL,
    calendar_access jsonb NOT NULL,
    calendar_purpose public.calendar_purpose_enum NOT NULL,
    event_timestamp timestamp without time zone NOT NULL,
    ringer timestamp without time zone NOT NULL,
    files text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.calendar OWNER TO postgres;

--
-- Name: calendar_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.calendar ALTER COLUMN calendar_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.calendar_calendar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: calendaraccess; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calendaraccess (
    calendar_id integer NOT NULL,
    teacher_id integer NOT NULL,
    to_course_id integer,
    access_types jsonb
);


ALTER TABLE public.calendaraccess OWNER TO postgres;

--
-- Name: calendaraccess_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.calendaraccess ALTER COLUMN calendar_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.calendaraccess_calendar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: classroomproperties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.classroomproperties (
    classroom_properties_id integer NOT NULL,
    classroom_id integer NOT NULL,
    classroom_type character varying(50) NOT NULL,
    number_of_desks_chairs integer NOT NULL,
    number_of_pcs integer NOT NULL,
    desks_chairs_json jsonb,
    pcs_json jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.classroomproperties OWNER TO postgres;

--
-- Name: classroomproperties_classroom_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.classroomproperties ALTER COLUMN classroom_properties_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.classroomproperties_classroom_properties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: classrooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.classrooms (
    classroom_id integer NOT NULL,
    department_id integer,
    classroom_type public.classroom_type_enum NOT NULL,
    classroom_number character(5) NOT NULL,
    projector public.projector_enum DEFAULT 'yes'::public.projector_enum NOT NULL,
    tv public.tv_enum DEFAULT 'yes'::public.tv_enum NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    capacity integer NOT NULL
);


ALTER TABLE public.classrooms OWNER TO postgres;

--
-- Name: classrooms_classroom_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.classrooms ALTER COLUMN classroom_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.classrooms_classroom_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clubmembers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clubmembers (
    club_member_id integer NOT NULL,
    student_club_id integer NOT NULL,
    student_id integer NOT NULL,
    volunteer_hours integer NOT NULL,
    volunteer_hours_attendance jsonb NOT NULL,
    join_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.clubmembers OWNER TO postgres;

--
-- Name: clubmembers_club_member_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.clubmembers ALTER COLUMN club_member_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.clubmembers_club_member_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts (
    contract_id integer NOT NULL,
    contract_name character(50) NOT NULL,
    contracts_year integer NOT NULL,
    contract text NOT NULL,
    to_user jsonb,
    major_id integer,
    to_student_year character(15) DEFAULT NULL::bpchar,
    to_student_id character(8) DEFAULT NULL::bpchar,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    send_at timestamp without time zone NOT NULL
);


ALTER TABLE public.contracts OWNER TO postgres;

--
-- Name: contracts_contract_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.contracts ALTER COLUMN contract_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.contracts_contract_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: coursematerial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coursematerial (
    course_material_id integer NOT NULL,
    course_id integer NOT NULL,
    week integer NOT NULL,
    material_type public.material_type_enum NOT NULL,
    material_name character(25) NOT NULL,
    material_url text NOT NULL,
    description character varying(100),
    is_submission_required boolean DEFAULT true,
    submission_url text,
    points numeric(2,2),
    allowed_attempts integer NOT NULL,
    due_date timestamp without time zone,
    available_from timestamp without time zone,
    available_until timestamp without time zone,
    major_id integer NOT NULL,
    teacher_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.coursematerial OWNER TO postgres;

--
-- Name: coursematerial_course_material_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.coursematerial ALTER COLUMN course_material_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.coursematerial_course_material_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    course_id integer NOT NULL,
    course_name character varying(50) NOT NULL,
    course_code character(6) NOT NULL,
    course_type public.course_type_enum NOT NULL,
    course_year character varying(10) NOT NULL,
    total_credits integer NOT NULL,
    major_id integer NOT NULL,
    description character varying(100) DEFAULT '*'::character varying NOT NULL,
    course_season public.course_season_type_enum DEFAULT 'Намар, Өвөл, Хавар, Зун'::public.course_season_type_enum NOT NULL,
    times_per_week integer DEFAULT 0
);


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: courses_course_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.courses ALTER COLUMN course_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.courses_course_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.department (
    department_id integer NOT NULL,
    department_name character varying(50) NOT NULL,
    department_code character varying(10) NOT NULL,
    department_email character varying(50) NOT NULL,
    number_of_staff integer,
    logo text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    department_of_edu_id integer NOT NULL
);


ALTER TABLE public.department OWNER TO postgres;

--
-- Name: department_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.department ALTER COLUMN department_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.department_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: departmentsofeducation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departmentsofeducation (
    departments_of_education_id integer NOT NULL,
    ed_department_name character varying(50) NOT NULL,
    ed_department_code character varying(10) NOT NULL,
    teachers jsonb
);


ALTER TABLE public.departmentsofeducation OWNER TO postgres;

--
-- Name: departmentsofeducation_departments_of_education_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.departmentsofeducation ALTER COLUMN departments_of_education_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.departmentsofeducation_departments_of_education_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: grades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grades (
    grade_id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    course_grade numeric(3,2) DEFAULT NULL::numeric,
    grade_letter character(5) DEFAULT NULL::bpchar,
    finals_grade character(10) DEFAULT NULL::bpchar,
    graded_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    calculated_credit_grade integer DEFAULT 0 NOT NULL,
    net_credit_of_semester integer NOT NULL,
    credits_collected_of_semester integer DEFAULT 0 NOT NULL,
    semester_gpa numeric(1,2) DEFAULT NULL::numeric,
    semester_average numeric(3,2) DEFAULT NULL::numeric,
    prelimenary_grade numeric(3,2) DEFAULT NULL::numeric,
    overall_credits integer NOT NULL,
    overall_credits_collected integer DEFAULT 0 NOT NULL,
    overall_gpa numeric(1,2) DEFAULT NULL::numeric,
    overall_average numeric(3,2) DEFAULT NULL::numeric
);


ALTER TABLE public.grades OWNER TO postgres;

--
-- Name: grades_grade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.grades ALTER COLUMN grade_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.grades_grade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: internalmessagingclub; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.internalmessagingclub (
    internal_messaging_id integer NOT NULL,
    student_club_id integer NOT NULL,
    club_member_id integer NOT NULL,
    student_id integer NOT NULL,
    club_member_message jsonb NOT NULL,
    mention_someone integer,
    replied_to integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.internalmessagingclub OWNER TO postgres;

--
-- Name: internalmessagingclub_internal_messaging_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.internalmessagingclub ALTER COLUMN internal_messaging_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.internalmessagingclub_internal_messaging_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventoryofteacher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventoryofteacher (
    inventory_of_teacher_id integer NOT NULL,
    teacher_id integer NOT NULL,
    inventory_name character varying(100) NOT NULL,
    inventory_number character varying(15) NOT NULL,
    unit character(5) NOT NULL,
    quantity integer NOT NULL,
    unit_cost numeric(10,2) DEFAULT NULL::numeric,
    net_cost numeric(10,2) DEFAULT NULL::numeric,
    returned_quantity numeric(10,2) DEFAULT NULL::numeric,
    returned_unit_cost numeric(10,2) DEFAULT NULL::numeric,
    returned_net_cost numeric(10,2) DEFAULT NULL::numeric,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventoryofteacher OWNER TO postgres;

--
-- Name: inventoryofteacher_inventory_of_teacher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.inventoryofteacher ALTER COLUMN inventory_of_teacher_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.inventoryofteacher_inventory_of_teacher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invitations (
    invitation_id integer NOT NULL,
    student_id integer NOT NULL,
    major_id integer NOT NULL,
    course_id integer NOT NULL,
    teacher_id integer NOT NULL,
    status public.invitation_status_enum NOT NULL,
    invite jsonb NOT NULL,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invitations OWNER TO postgres;

--
-- Name: invitations_invitation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.invitations ALTER COLUMN invitation_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.invitations_invitation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: major; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.major (
    major_id integer NOT NULL,
    major_name character varying(50) NOT NULL,
    majors_year date NOT NULL,
    majors_type public.major_type_enum NOT NULL,
    credit_unit_rate money NOT NULL,
    major_tuition money NOT NULL,
    academic_degree character varying(20) NOT NULL,
    total_years integer NOT NULL,
    total_credits_per_year integer NOT NULL,
    department_of_edu_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    exam1 double precision NOT NULL,
    exam2 double precision NOT NULL,
    majors_description character varying(700) NOT NULL,
    description_brief character varying(50),
    qualifications jsonb,
    qualifications1 text,
    qualifications2 text,
    sign_ups public.sign_ups_enum DEFAULT 'бүртгэл нээлттэй'::public.sign_ups_enum NOT NULL,
    department_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.major OWNER TO postgres;

--
-- Name: major_major_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.major ALTER COLUMN major_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.major_major_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notificationstudents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notificationstudents (
    notification_students_id integer NOT NULL,
    teacher_id integer NOT NULL,
    course_id integer NOT NULL,
    to_student integer NOT NULL,
    notification_message jsonb NOT NULL,
    course_material_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notificationstudents OWNER TO postgres;

--
-- Name: notificationstudents_notification_students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.notificationstudents ALTER COLUMN notification_students_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.notificationstudents_notification_students_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: paymentinformation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentinformation (
    payment_information_id integer NOT NULL,
    payment_to_pay numeric(10,2) DEFAULT NULL::numeric,
    payed_payments numeric(10,2) DEFAULT NULL::numeric,
    gross_payment numeric(10,2) DEFAULT NULL::numeric,
    balance numeric(10,2) DEFAULT NULL::numeric,
    payment_unit_credit numeric(10,2) DEFAULT NULL::numeric,
    student_id integer NOT NULL,
    major_id integer NOT NULL
);


ALTER TABLE public.paymentinformation OWNER TO postgres;

--
-- Name: paymentinformation_payment_information_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.paymentinformation ALTER COLUMN payment_information_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.paymentinformation_payment_information_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: paymentlessonsselection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paymentlessonsselection (
    lesson_selection_id integer NOT NULL,
    student_id integer NOT NULL,
    payment_information_id integer NOT NULL,
    student_curriculum_id integer NOT NULL,
    course_payment numeric(10,2) DEFAULT NULL::numeric,
    credit_unit_payment numeric(10,2) NOT NULL,
    course_credits integer NOT NULL,
    discount numeric(10,2) DEFAULT NULL::numeric,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    net_credit integer NOT NULL,
    gross_payment numeric(10,2) DEFAULT NULL::numeric,
    gross_discount numeric(10,2) DEFAULT NULL::numeric
);


ALTER TABLE public.paymentlessonsselection OWNER TO postgres;

--
-- Name: paymentlessonsselection_lesson_selection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.paymentlessonsselection ALTER COLUMN lesson_selection_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.paymentlessonsselection_lesson_selection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: propertyofteacher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.propertyofteacher (
    property_of_teacher_id integer NOT NULL,
    teacher_id integer NOT NULL,
    property_number character varying(100) NOT NULL,
    property_category public.property_category_enum NOT NULL,
    property_code character varying(10) NOT NULL,
    property_name_and_model timestamp without time zone NOT NULL,
    started_using timestamp without time zone NOT NULL,
    state_of_usage public.state_of_usage_enum NOT NULL,
    price numeric(10,2) DEFAULT NULL::numeric,
    location character varying(50) NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.propertyofteacher OWNER TO postgres;

--
-- Name: propertyofteacher_property_of_teacher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.propertyofteacher ALTER COLUMN property_of_teacher_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.propertyofteacher_property_of_teacher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rules (
    rule_id integer NOT NULL,
    rule_category public.rule_category_enum NOT NULL,
    rule_name character varying(100) NOT NULL,
    rule_pdf text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rules OWNER TO postgres;

--
-- Name: rules_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rules ALTER COLUMN rule_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rules_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: signedcontracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.signedcontracts (
    singed_contract_id integer NOT NULL,
    contract_id integer NOT NULL,
    user_id integer,
    student_id integer,
    contract text NOT NULL,
    signed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.signedcontracts OWNER TO postgres;

--
-- Name: signedcontracts_singed_contract_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.signedcontracts ALTER COLUMN singed_contract_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.signedcontracts_singed_contract_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    staff_id integer NOT NULL,
    user_id integer NOT NULL,
    staff_role public.staff_role_enum NOT NULL,
    staff_code integer NOT NULL,
    staff_email character varying(50) NOT NULL,
    family_description character(100) NOT NULL,
    cv text,
    certificate text,
    department_id integer NOT NULL,
    job_position character(50) NOT NULL,
    job_location character varying(100) NOT NULL,
    job_description character(50) NOT NULL
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_staff_code_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_staff_code_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_staff_code_seq OWNER TO postgres;

--
-- Name: staff_staff_code_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_staff_code_seq OWNED BY public.staff.staff_code;


--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.staff ALTER COLUMN staff_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.staff_staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student (
    student_id integer NOT NULL,
    user_id integer NOT NULL,
    student_club_id integer,
    additional_roles public.additional_roles_enum DEFAULT 'байхгүй'::public.additional_roles_enum NOT NULL,
    student_code character(8) NOT NULL,
    student_email character varying(50) NOT NULL,
    student_file jsonb,
    enrollment_number integer NOT NULL,
    enrollment_year integer NOT NULL,
    year_classification public.year_classification_enum NOT NULL,
    is_active public.student_is_active_enum DEFAULT 'суралцаж байгаа'::public.student_is_active_enum,
    current_academic_degree character(25) NOT NULL,
    academic_degree_file text,
    major_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    contracts jsonb,
    department_id integer
);


ALTER TABLE public.student OWNER TO postgres;

--
-- Name: student_enrollment_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_enrollment_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.student_enrollment_number_seq OWNER TO postgres;

--
-- Name: student_enrollment_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_enrollment_number_seq OWNED BY public.student.enrollment_number;


--
-- Name: student_student_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.student ALTER COLUMN student_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.student_student_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentansweredsurvey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentansweredsurvey (
    answered_survey_id integer NOT NULL,
    survey_id integer NOT NULL,
    major_id integer NOT NULL,
    student_id integer NOT NULL,
    recieved_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    answers_json text NOT NULL
);


ALTER TABLE public.studentansweredsurvey OWNER TO postgres;

--
-- Name: studentansweredsurvey_answered_survey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentansweredsurvey ALTER COLUMN answered_survey_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentansweredsurvey_answered_survey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentattendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentattendance (
    attendance_id integer NOT NULL,
    course_id integer NOT NULL,
    course_material_id integer NOT NULL,
    week_title integer NOT NULL,
    student_attendance public.student_attendance_enum NOT NULL,
    student_balance numeric(10,2) DEFAULT NULL::numeric,
    gross_transaction_amount numeric(10,2) DEFAULT NULL::numeric,
    student_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentattendance OWNER TO postgres;

--
-- Name: studentattendance_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentattendance ALTER COLUMN attendance_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentattendance_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentbalance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentbalance (
    student_balance_id integer NOT NULL,
    student_id integer NOT NULL,
    transaction_info_id integer NOT NULL,
    student_code character(15),
    registry_number character(15),
    student_balance numeric(10,2) DEFAULT NULL::numeric,
    gross_transaction_amount numeric(10,2) DEFAULT NULL::numeric,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentbalance OWNER TO postgres;

--
-- Name: studentbalance_student_balance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentbalance ALTER COLUMN student_balance_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentbalance_student_balance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentclubevent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentclubevent (
    club_event_id integer NOT NULL,
    student_club_id integer NOT NULL,
    club_type character(25) NOT NULL,
    event_type public.event_type_enum NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    description character varying(200) NOT NULL,
    files text NOT NULL,
    title character(50) NOT NULL,
    attendees jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentclubevent OWNER TO postgres;

--
-- Name: studentclubevent_club_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentclubevent ALTER COLUMN club_event_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentclubevent_club_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentclubs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentclubs (
    student_club_id integer NOT NULL,
    club_code character varying(10) NOT NULL,
    club_name character varying(50) NOT NULL,
    club_members integer DEFAULT 0 NOT NULL,
    club_type public.club_type_enum DEFAULT 'professional_club'::public.club_type_enum NOT NULL,
    club_major_id integer NOT NULL,
    club_primary_leader_id integer NOT NULL,
    club_assistant_leader_id integer NOT NULL,
    club_advisor_teacher_id integer NOT NULL,
    club_logo text NOT NULL,
    club_moto character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentclubs OWNER TO postgres;

--
-- Name: studentclubs_student_club_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentclubs ALTER COLUMN student_club_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentclubs_student_club_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentcurriculum; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentcurriculum (
    student_curriculum_id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    credit integer NOT NULL,
    student_curriculum_year date NOT NULL,
    semester_year character(25) NOT NULL,
    modified_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentcurriculum OWNER TO postgres;

--
-- Name: studentcurriculum_student_curriculum_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentcurriculum ALTER COLUMN student_curriculum_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentcurriculum_student_curriculum_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentschedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentschedule (
    student_curriculum_id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    student_schedule_year date NOT NULL,
    classroom_number character(10) NOT NULL,
    class_group integer NOT NULL,
    semester_year character(25) NOT NULL,
    modified_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentschedule OWNER TO postgres;

--
-- Name: studentschedule_student_curriculum_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentschedule ALTER COLUMN student_curriculum_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentschedule_student_curriculum_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentstoadvise; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentstoadvise (
    students_to_advise_id integer NOT NULL,
    teacher_id integer NOT NULL,
    academic_degree_of_major character varying(20) NOT NULL,
    major_id numeric(10,2) DEFAULT NULL::numeric,
    course_id integer NOT NULL,
    student_id integer NOT NULL,
    students_full_name character varying(25) NOT NULL,
    student_phone_numbers character(50) NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.studentstoadvise OWNER TO postgres;

--
-- Name: studentstoadvise_students_to_advise_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentstoadvise ALTER COLUMN students_to_advise_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentstoadvise_students_to_advise_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: submission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.submission (
    submission_id integer NOT NULL,
    course_material_id integer NOT NULL,
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    submission_file text NOT NULL,
    student_id integer NOT NULL,
    graded_points numeric(2,2),
    grade_status public.grade_status_enum DEFAULT 'submitted'::public.grade_status_enum NOT NULL,
    grader_comment text,
    teacher_id integer NOT NULL,
    graded_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.submission OWNER TO postgres;

--
-- Name: submission_submission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.submission ALTER COLUMN submission_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.submission_submission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: surveys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.surveys (
    surveys_id integer NOT NULL,
    survey_name character(25) NOT NULL,
    due_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    major_id integer NOT NULL,
    to_student_year integer NOT NULL,
    to_student_id integer NOT NULL,
    questions_json text NOT NULL
);


ALTER TABLE public.surveys OWNER TO postgres;

--
-- Name: surveys_surveys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.surveys ALTER COLUMN surveys_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.surveys_surveys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: teacher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teacher (
    teacher_id integer NOT NULL,
    user_id integer NOT NULL,
    teacher_code character varying(10) NOT NULL,
    teacher_email character varying(50) NOT NULL,
    certificate text,
    profession character(25) NOT NULL,
    academic_degree character(25) NOT NULL,
    job_title text,
    is_active public.is_active_enum DEFAULT 'is_working'::public.is_active_enum NOT NULL,
    job_description character(100) DEFAULT 'Багшлах'::bpchar NOT NULL,
    departments_of_education_id integer NOT NULL,
    department_id integer
);


ALTER TABLE public.teacher OWNER TO postgres;

--
-- Name: teacher_teacher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.teacher ALTER COLUMN teacher_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.teacher_teacher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: teacherscourseplanning; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teacherscourseplanning (
    teacher_course_planning_id integer NOT NULL,
    teacher_id integer NOT NULL,
    major_name character varying(50) NOT NULL,
    major_id integer DEFAULT NULL::numeric NOT NULL,
    course_name character varying(50) NOT NULL,
    credit integer NOT NULL,
    course_id integer NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    department_of_edu_id integer NOT NULL,
    course_code character varying(6) NOT NULL,
    teacher_major_id integer NOT NULL
);


ALTER TABLE public.teacherscourseplanning OWNER TO postgres;

--
-- Name: teachercourseplanning_teacher_course_planning_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.teacherscourseplanning ALTER COLUMN teacher_course_planning_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.teachercourseplanning_teacher_course_planning_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: teacherschedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teacherschedule (
    teacher_schedule_id integer NOT NULL,
    teacher_id integer NOT NULL,
    week_day character varying(20) NOT NULL,
    period_of_class character varying(50) NOT NULL,
    classroom_id integer NOT NULL,
    class_group character varying(10) NOT NULL,
    course_name character varying(50) NOT NULL,
    credit integer NOT NULL,
    number_of_students integer NOT NULL,
    course_id integer NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.teacherschedule OWNER TO postgres;

--
-- Name: teacherschedule_teacher_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.teacherschedule ALTER COLUMN teacher_schedule_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.teacherschedule_teacher_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: teachersmajorplanning; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teachersmajorplanning (
    teacher_major_id integer NOT NULL,
    teacher_id integer NOT NULL,
    academic_degree_of_major character varying(20) NOT NULL,
    major_name character varying(50) NOT NULL,
    major_id integer DEFAULT NULL::numeric NOT NULL,
    credit integer NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    department_of_educations_id integer NOT NULL
);


ALTER TABLE public.teachersmajorplanning OWNER TO postgres;

--
-- Name: teachersmajorplanning_teacher_major_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.teachersmajorplanning ALTER COLUMN teacher_major_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.teachersmajorplanning_teacher_major_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: teachersschedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teachersschedule (
    classroom_id integer DEFAULT 0,
    students integer DEFAULT 0,
    teacher_id integer NOT NULL,
    course_id integer NOT NULL,
    major_id integer NOT NULL,
    teacher_name character varying(50) NOT NULL,
    teachers_email character varying(50) NOT NULL,
    schedule_type public.schedule_type_enum DEFAULT 'Лаборатори'::public.schedule_type_enum,
    "time" public.schedule_time_type_enum NOT NULL,
    course_planning_id integer DEFAULT 0 NOT NULL,
    days public.days_type_enum NOT NULL,
    teachers_schedule_id integer NOT NULL,
    created_at date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    course_name character varying(50) NOT NULL,
    classroom_capacity integer,
    classroom_type public.classroom_type_enum,
    classroom_number character varying(5)
);


ALTER TABLE public.teachersschedule OWNER TO postgres;

--
-- Name: teachersschedule_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.teachersschedule ALTER COLUMN teachers_schedule_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.teachersschedule_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transactioninformation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactioninformation (
    transaction_info_id integer NOT NULL,
    student_id integer NOT NULL,
    reciept text,
    recipient_bank character(25) NOT NULL,
    transaction_string character(100) NOT NULL,
    transaction_amount numeric(10,2) DEFAULT NULL::numeric,
    parsed_string integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transactioninformation OWNER TO postgres;

--
-- Name: transactioninformation_transaction_info_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.transactioninformation ALTER COLUMN transaction_info_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.transactioninformation_transaction_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_signatures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_signatures (
    user_signature_id integer NOT NULL,
    user_id integer,
    user_registry_number character varying(10),
    user_role public.user_role_enum NOT NULL,
    signature bytea
);


ALTER TABLE public.user_signatures OWNER TO postgres;

--
-- Name: user_signatures_user_signature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_signatures ALTER COLUMN user_signature_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_signatures_user_signature_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: usercard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usercard (
    user_card_id integer NOT NULL,
    card_code integer NOT NULL,
    user_id integer NOT NULL,
    user_role public.user_role_enum DEFAULT 'student'::public.user_role_enum NOT NULL,
    user_information jsonb NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_until timestamp without time zone NOT NULL,
    recieved public.recieved_enum DEFAULT 'yes'::public.recieved_enum NOT NULL,
    signature text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usercard OWNER TO postgres;

--
-- Name: usercard_user_card_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.usercard ALTER COLUMN user_card_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.usercard_user_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: userprofiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userprofiles (
    profile_id integer NOT NULL,
    user_id integer NOT NULL,
    user_code character(10) NOT NULL,
    user_role character(25) NOT NULL,
    profile_picture text NOT NULL,
    description character varying(100) NOT NULL,
    department_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.userprofiles OWNER TO postgres;

--
-- Name: userprofiles_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.userprofiles ALTER COLUMN profile_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.userprofiles_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: staff staff_code; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN staff_code SET DEFAULT nextval('public.staff_staff_code_seq'::regclass);


--
-- Name: student enrollment_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student ALTER COLUMN enrollment_number SET DEFAULT nextval('public.student_enrollment_number_seq'::regclass);


--
-- Data for Name: announcement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcement (announcement_id, student_id, major_id, course_id, teacher_id, status, announcement, announcement_options, sent_at) FROM stdin;
\.
COPY public.announcement (announcement_id, student_id, major_id, course_id, teacher_id, status, announcement, announcement_options, sent_at) FROM '$$PATH$$/5482.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (user_id, login_name, password_hash, profile_picture, registry_number, user_role, fname, lname, birthday, gender, citizenship, state_city, town_district, valid_address, state_city_living, town_district_living, valid_address_living, postal_address, home_phone_number, phone_number, phone_number_emergency, country, ethnicity, social_background, state_city_of_birth, town_district_of_birth, place_of_birth, education, current_academic_degree, profession, profession_certification, f_passport_number, married, military_service, pensions_established, additional_notes, blood_type, drivers_certificate, drivers_certificate_number, disabled, is_active, email, created_at, family_tree_name) FROM stdin;
\.
COPY public.auth_user (user_id, login_name, password_hash, profile_picture, registry_number, user_role, fname, lname, birthday, gender, citizenship, state_city, town_district, valid_address, state_city_living, town_district_living, valid_address_living, postal_address, home_phone_number, phone_number, phone_number_emergency, country, ethnicity, social_background, state_city_of_birth, town_district_of_birth, place_of_birth, education, current_academic_degree, profession, profession_certification, f_passport_number, married, military_service, pensions_established, additional_notes, blood_type, drivers_certificate, drivers_certificate_number, disabled, is_active, email, created_at, family_tree_name) FROM '$$PATH$$/5484.dat';

--
-- Data for Name: basecurriculum; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.basecurriculum (base_curriculum_id, major_id, course_id, curriculum_year, semester_year) FROM stdin;
\.
COPY public.basecurriculum (base_curriculum_id, major_id, course_id, curriculum_year, semester_year) FROM '$$PATH$$/5486.dat';

--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calendar (calendar_id, teacher_id, calendar_title, calendar_access, calendar_purpose, event_timestamp, ringer, files, created_at) FROM stdin;
\.
COPY public.calendar (calendar_id, teacher_id, calendar_title, calendar_access, calendar_purpose, event_timestamp, ringer, files, created_at) FROM '$$PATH$$/5488.dat';

--
-- Data for Name: calendaraccess; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calendaraccess (calendar_id, teacher_id, to_course_id, access_types) FROM stdin;
\.
COPY public.calendaraccess (calendar_id, teacher_id, to_course_id, access_types) FROM '$$PATH$$/5490.dat';

--
-- Data for Name: classroomproperties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.classroomproperties (classroom_properties_id, classroom_id, classroom_type, number_of_desks_chairs, number_of_pcs, desks_chairs_json, pcs_json, created_at) FROM stdin;
\.
COPY public.classroomproperties (classroom_properties_id, classroom_id, classroom_type, number_of_desks_chairs, number_of_pcs, desks_chairs_json, pcs_json, created_at) FROM '$$PATH$$/5492.dat';

--
-- Data for Name: classrooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.classrooms (classroom_id, department_id, classroom_type, classroom_number, projector, tv, created_at, capacity) FROM stdin;
\.
COPY public.classrooms (classroom_id, department_id, classroom_type, classroom_number, projector, tv, created_at, capacity) FROM '$$PATH$$/5494.dat';

--
-- Data for Name: clubmembers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clubmembers (club_member_id, student_club_id, student_id, volunteer_hours, volunteer_hours_attendance, join_date) FROM stdin;
\.
COPY public.clubmembers (club_member_id, student_club_id, student_id, volunteer_hours, volunteer_hours_attendance, join_date) FROM '$$PATH$$/5496.dat';

--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts (contract_id, contract_name, contracts_year, contract, to_user, major_id, to_student_year, to_student_id, created_at, send_at) FROM stdin;
\.
COPY public.contracts (contract_id, contract_name, contracts_year, contract, to_user, major_id, to_student_year, to_student_id, created_at, send_at) FROM '$$PATH$$/5498.dat';

--
-- Data for Name: coursematerial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coursematerial (course_material_id, course_id, week, material_type, material_name, material_url, description, is_submission_required, submission_url, points, allowed_attempts, due_date, available_from, available_until, major_id, teacher_id, created_at) FROM stdin;
\.
COPY public.coursematerial (course_material_id, course_id, week, material_type, material_name, material_url, description, is_submission_required, submission_url, points, allowed_attempts, due_date, available_from, available_until, major_id, teacher_id, created_at) FROM '$$PATH$$/5500.dat';

--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (course_id, course_name, course_code, course_type, course_year, total_credits, major_id, description, course_season, times_per_week) FROM stdin;
\.
COPY public.courses (course_id, course_name, course_code, course_type, course_year, total_credits, major_id, description, course_season, times_per_week) FROM '$$PATH$$/5502.dat';

--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.department (department_id, department_name, department_code, department_email, number_of_staff, logo, created_at, department_of_edu_id) FROM stdin;
\.
COPY public.department (department_id, department_name, department_code, department_email, number_of_staff, logo, created_at, department_of_edu_id) FROM '$$PATH$$/5504.dat';

--
-- Data for Name: departmentsofeducation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departmentsofeducation (departments_of_education_id, ed_department_name, ed_department_code, teachers) FROM stdin;
\.
COPY public.departmentsofeducation (departments_of_education_id, ed_department_name, ed_department_code, teachers) FROM '$$PATH$$/5506.dat';

--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grades (grade_id, student_id, course_id, course_grade, grade_letter, finals_grade, graded_date, calculated_credit_grade, net_credit_of_semester, credits_collected_of_semester, semester_gpa, semester_average, prelimenary_grade, overall_credits, overall_credits_collected, overall_gpa, overall_average) FROM stdin;
\.
COPY public.grades (grade_id, student_id, course_id, course_grade, grade_letter, finals_grade, graded_date, calculated_credit_grade, net_credit_of_semester, credits_collected_of_semester, semester_gpa, semester_average, prelimenary_grade, overall_credits, overall_credits_collected, overall_gpa, overall_average) FROM '$$PATH$$/5508.dat';

--
-- Data for Name: internalmessagingclub; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.internalmessagingclub (internal_messaging_id, student_club_id, club_member_id, student_id, club_member_message, mention_someone, replied_to, created_at) FROM stdin;
\.
COPY public.internalmessagingclub (internal_messaging_id, student_club_id, club_member_id, student_id, club_member_message, mention_someone, replied_to, created_at) FROM '$$PATH$$/5510.dat';

--
-- Data for Name: inventoryofteacher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventoryofteacher (inventory_of_teacher_id, teacher_id, inventory_name, inventory_number, unit, quantity, unit_cost, net_cost, returned_quantity, returned_unit_cost, returned_net_cost, department_id, created_at) FROM stdin;
\.
COPY public.inventoryofteacher (inventory_of_teacher_id, teacher_id, inventory_name, inventory_number, unit, quantity, unit_cost, net_cost, returned_quantity, returned_unit_cost, returned_net_cost, department_id, created_at) FROM '$$PATH$$/5512.dat';

--
-- Data for Name: invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invitations (invitation_id, student_id, major_id, course_id, teacher_id, status, invite, sent_at) FROM stdin;
\.
COPY public.invitations (invitation_id, student_id, major_id, course_id, teacher_id, status, invite, sent_at) FROM '$$PATH$$/5514.dat';

--
-- Data for Name: major; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.major (major_id, major_name, majors_year, majors_type, credit_unit_rate, major_tuition, academic_degree, total_years, total_credits_per_year, department_of_edu_id, created_at, exam1, exam2, majors_description, description_brief, qualifications, qualifications1, qualifications2, sign_ups, department_id) FROM stdin;
\.
COPY public.major (major_id, major_name, majors_year, majors_type, credit_unit_rate, major_tuition, academic_degree, total_years, total_credits_per_year, department_of_edu_id, created_at, exam1, exam2, majors_description, description_brief, qualifications, qualifications1, qualifications2, sign_ups, department_id) FROM '$$PATH$$/5516.dat';

--
-- Data for Name: notificationstudents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notificationstudents (notification_students_id, teacher_id, course_id, to_student, notification_message, course_material_id, created_at) FROM stdin;
\.
COPY public.notificationstudents (notification_students_id, teacher_id, course_id, to_student, notification_message, course_material_id, created_at) FROM '$$PATH$$/5518.dat';

--
-- Data for Name: paymentinformation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentinformation (payment_information_id, payment_to_pay, payed_payments, gross_payment, balance, payment_unit_credit, student_id, major_id) FROM stdin;
\.
COPY public.paymentinformation (payment_information_id, payment_to_pay, payed_payments, gross_payment, balance, payment_unit_credit, student_id, major_id) FROM '$$PATH$$/5520.dat';

--
-- Data for Name: paymentlessonsselection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paymentlessonsselection (lesson_selection_id, student_id, payment_information_id, student_curriculum_id, course_payment, credit_unit_payment, course_credits, discount, created_at, net_credit, gross_payment, gross_discount) FROM stdin;
\.
COPY public.paymentlessonsselection (lesson_selection_id, student_id, payment_information_id, student_curriculum_id, course_payment, credit_unit_payment, course_credits, discount, created_at, net_credit, gross_payment, gross_discount) FROM '$$PATH$$/5522.dat';

--
-- Data for Name: propertyofteacher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.propertyofteacher (property_of_teacher_id, teacher_id, property_number, property_category, property_code, property_name_and_model, started_using, state_of_usage, price, location, department_id, created_at) FROM stdin;
\.
COPY public.propertyofteacher (property_of_teacher_id, teacher_id, property_number, property_category, property_code, property_name_and_model, started_using, state_of_usage, price, location, department_id, created_at) FROM '$$PATH$$/5524.dat';

--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rules (rule_id, rule_category, rule_name, rule_pdf, created_at) FROM stdin;
\.
COPY public.rules (rule_id, rule_category, rule_name, rule_pdf, created_at) FROM '$$PATH$$/5526.dat';

--
-- Data for Name: signedcontracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.signedcontracts (singed_contract_id, contract_id, user_id, student_id, contract, signed_at) FROM stdin;
\.
COPY public.signedcontracts (singed_contract_id, contract_id, user_id, student_id, contract, signed_at) FROM '$$PATH$$/5528.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (staff_id, user_id, staff_role, staff_code, staff_email, family_description, cv, certificate, department_id, job_position, job_location, job_description) FROM stdin;
\.
COPY public.staff (staff_id, user_id, staff_role, staff_code, staff_email, family_description, cv, certificate, department_id, job_position, job_location, job_description) FROM '$$PATH$$/5530.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student (student_id, user_id, student_club_id, additional_roles, student_code, student_email, student_file, enrollment_number, enrollment_year, year_classification, is_active, current_academic_degree, academic_degree_file, major_id, created_at, contracts, department_id) FROM stdin;
\.
COPY public.student (student_id, user_id, student_club_id, additional_roles, student_code, student_email, student_file, enrollment_number, enrollment_year, year_classification, is_active, current_academic_degree, academic_degree_file, major_id, created_at, contracts, department_id) FROM '$$PATH$$/5533.dat';

--
-- Data for Name: studentansweredsurvey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentansweredsurvey (answered_survey_id, survey_id, major_id, student_id, recieved_at, answers_json) FROM stdin;
\.
COPY public.studentansweredsurvey (answered_survey_id, survey_id, major_id, student_id, recieved_at, answers_json) FROM '$$PATH$$/5536.dat';

--
-- Data for Name: studentattendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentattendance (attendance_id, course_id, course_material_id, week_title, student_attendance, student_balance, gross_transaction_amount, student_id, created_at) FROM stdin;
\.
COPY public.studentattendance (attendance_id, course_id, course_material_id, week_title, student_attendance, student_balance, gross_transaction_amount, student_id, created_at) FROM '$$PATH$$/5538.dat';

--
-- Data for Name: studentbalance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentbalance (student_balance_id, student_id, transaction_info_id, student_code, registry_number, student_balance, gross_transaction_amount, created_at) FROM stdin;
\.
COPY public.studentbalance (student_balance_id, student_id, transaction_info_id, student_code, registry_number, student_balance, gross_transaction_amount, created_at) FROM '$$PATH$$/5540.dat';

--
-- Data for Name: studentclubevent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentclubevent (club_event_id, student_club_id, club_type, event_type, "timestamp", description, files, title, attendees, created_at) FROM stdin;
\.
COPY public.studentclubevent (club_event_id, student_club_id, club_type, event_type, "timestamp", description, files, title, attendees, created_at) FROM '$$PATH$$/5542.dat';

--
-- Data for Name: studentclubs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentclubs (student_club_id, club_code, club_name, club_members, club_type, club_major_id, club_primary_leader_id, club_assistant_leader_id, club_advisor_teacher_id, club_logo, club_moto, created_at) FROM stdin;
\.
COPY public.studentclubs (student_club_id, club_code, club_name, club_members, club_type, club_major_id, club_primary_leader_id, club_assistant_leader_id, club_advisor_teacher_id, club_logo, club_moto, created_at) FROM '$$PATH$$/5544.dat';

--
-- Data for Name: studentcurriculum; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentcurriculum (student_curriculum_id, student_id, course_id, credit, student_curriculum_year, semester_year, modified_at) FROM stdin;
\.
COPY public.studentcurriculum (student_curriculum_id, student_id, course_id, credit, student_curriculum_year, semester_year, modified_at) FROM '$$PATH$$/5546.dat';

--
-- Data for Name: studentschedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentschedule (student_curriculum_id, student_id, course_id, student_schedule_year, classroom_number, class_group, semester_year, modified_at) FROM stdin;
\.
COPY public.studentschedule (student_curriculum_id, student_id, course_id, student_schedule_year, classroom_number, class_group, semester_year, modified_at) FROM '$$PATH$$/5548.dat';

--
-- Data for Name: studentstoadvise; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentstoadvise (students_to_advise_id, teacher_id, academic_degree_of_major, major_id, course_id, student_id, students_full_name, student_phone_numbers, department_id, created_at) FROM stdin;
\.
COPY public.studentstoadvise (students_to_advise_id, teacher_id, academic_degree_of_major, major_id, course_id, student_id, students_full_name, student_phone_numbers, department_id, created_at) FROM '$$PATH$$/5550.dat';

--
-- Data for Name: submission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.submission (submission_id, course_material_id, submitted_at, submission_file, student_id, graded_points, grade_status, grader_comment, teacher_id, graded_at, created_at) FROM stdin;
\.
COPY public.submission (submission_id, course_material_id, submitted_at, submission_file, student_id, graded_points, grade_status, grader_comment, teacher_id, graded_at, created_at) FROM '$$PATH$$/5552.dat';

--
-- Data for Name: surveys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.surveys (surveys_id, survey_name, due_date, created_at, major_id, to_student_year, to_student_id, questions_json) FROM stdin;
\.
COPY public.surveys (surveys_id, survey_name, due_date, created_at, major_id, to_student_year, to_student_id, questions_json) FROM '$$PATH$$/5554.dat';

--
-- Data for Name: teacher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teacher (teacher_id, user_id, teacher_code, teacher_email, certificate, profession, academic_degree, job_title, is_active, job_description, departments_of_education_id, department_id) FROM stdin;
\.
COPY public.teacher (teacher_id, user_id, teacher_code, teacher_email, certificate, profession, academic_degree, job_title, is_active, job_description, departments_of_education_id, department_id) FROM '$$PATH$$/5556.dat';

--
-- Data for Name: teacherschedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teacherschedule (teacher_schedule_id, teacher_id, week_day, period_of_class, classroom_id, class_group, course_name, credit, number_of_students, course_id, department_id, created_at) FROM stdin;
\.
COPY public.teacherschedule (teacher_schedule_id, teacher_id, week_day, period_of_class, classroom_id, class_group, course_name, credit, number_of_students, course_id, department_id, created_at) FROM '$$PATH$$/5560.dat';

--
-- Data for Name: teacherscourseplanning; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teacherscourseplanning (teacher_course_planning_id, teacher_id, major_name, major_id, course_name, credit, course_id, department_id, created_at, department_of_edu_id, course_code, teacher_major_id) FROM stdin;
\.
COPY public.teacherscourseplanning (teacher_course_planning_id, teacher_id, major_name, major_id, course_name, credit, course_id, department_id, created_at, department_of_edu_id, course_code, teacher_major_id) FROM '$$PATH$$/5558.dat';

--
-- Data for Name: teachersmajorplanning; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teachersmajorplanning (teacher_major_id, teacher_id, academic_degree_of_major, major_name, major_id, credit, department_id, created_at, department_of_educations_id) FROM stdin;
\.
COPY public.teachersmajorplanning (teacher_major_id, teacher_id, academic_degree_of_major, major_name, major_id, credit, department_id, created_at, department_of_educations_id) FROM '$$PATH$$/5562.dat';

--
-- Data for Name: teachersschedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teachersschedule (classroom_id, students, teacher_id, course_id, major_id, teacher_name, teachers_email, schedule_type, "time", course_planning_id, days, teachers_schedule_id, created_at, course_name, classroom_capacity, classroom_type, classroom_number) FROM stdin;
\.
COPY public.teachersschedule (classroom_id, students, teacher_id, course_id, major_id, teacher_name, teachers_email, schedule_type, "time", course_planning_id, days, teachers_schedule_id, created_at, course_name, classroom_capacity, classroom_type, classroom_number) FROM '$$PATH$$/5564.dat';

--
-- Data for Name: transactioninformation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactioninformation (transaction_info_id, student_id, reciept, recipient_bank, transaction_string, transaction_amount, parsed_string, created_at) FROM stdin;
\.
COPY public.transactioninformation (transaction_info_id, student_id, reciept, recipient_bank, transaction_string, transaction_amount, parsed_string, created_at) FROM '$$PATH$$/5566.dat';

--
-- Data for Name: user_signatures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_signatures (user_signature_id, user_id, user_registry_number, user_role, signature) FROM stdin;
\.
COPY public.user_signatures (user_signature_id, user_id, user_registry_number, user_role, signature) FROM '$$PATH$$/5568.dat';

--
-- Data for Name: usercard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usercard (user_card_id, card_code, user_id, user_role, user_information, valid_from, valid_until, recieved, signature, created_at) FROM stdin;
\.
COPY public.usercard (user_card_id, card_code, user_id, user_role, user_information, valid_from, valid_until, recieved, signature, created_at) FROM '$$PATH$$/5570.dat';

--
-- Data for Name: userprofiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.userprofiles (profile_id, user_id, user_code, user_role, profile_picture, description, department_id, created_at) FROM stdin;
\.
COPY public.userprofiles (profile_id, user_id, user_code, user_role, profile_picture, description, department_id, created_at) FROM '$$PATH$$/5572.dat';

--
-- Name: announcement_announcement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcement_announcement_id_seq', 1, false);


--
-- Name: auth_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_id_seq', 148, true);


--
-- Name: basecurriculum_base_curriculum_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.basecurriculum_base_curriculum_id_seq', 1, false);


--
-- Name: calendar_calendar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendar_calendar_id_seq', 1, false);


--
-- Name: calendaraccess_calendar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calendaraccess_calendar_id_seq', 1, false);


--
-- Name: classroomproperties_classroom_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.classroomproperties_classroom_properties_id_seq', 13, true);


--
-- Name: classrooms_classroom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.classrooms_classroom_id_seq', 13, true);


--
-- Name: clubmembers_club_member_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clubmembers_club_member_id_seq', 1, false);


--
-- Name: contracts_contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contracts_contract_id_seq', 1, false);


--
-- Name: coursematerial_course_material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coursematerial_course_material_id_seq', 1, false);


--
-- Name: courses_course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.courses_course_id_seq', 76, true);


--
-- Name: department_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.department_department_id_seq', 8, true);


--
-- Name: departmentsofeducation_departments_of_education_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departmentsofeducation_departments_of_education_id_seq', 4, true);


--
-- Name: grades_grade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grades_grade_id_seq', 1, false);


--
-- Name: internalmessagingclub_internal_messaging_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.internalmessagingclub_internal_messaging_id_seq', 1, false);


--
-- Name: inventoryofteacher_inventory_of_teacher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventoryofteacher_inventory_of_teacher_id_seq', 1, false);


--
-- Name: invitations_invitation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invitations_invitation_id_seq', 1, false);


--
-- Name: major_major_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.major_major_id_seq', 33, true);


--
-- Name: notificationstudents_notification_students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notificationstudents_notification_students_id_seq', 1, false);


--
-- Name: paymentinformation_payment_information_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paymentinformation_payment_information_id_seq', 1, false);


--
-- Name: paymentlessonsselection_lesson_selection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paymentlessonsselection_lesson_selection_id_seq', 1, false);


--
-- Name: propertyofteacher_property_of_teacher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.propertyofteacher_property_of_teacher_id_seq', 1, false);


--
-- Name: rules_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rules_rule_id_seq', 1, false);


--
-- Name: signedcontracts_singed_contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.signedcontracts_singed_contract_id_seq', 1, false);


--
-- Name: staff_staff_code_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_code_seq', 1, false);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 1, false);


--
-- Name: student_enrollment_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_enrollment_number_seq', 1, false);


--
-- Name: student_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_student_id_seq', 21, true);


--
-- Name: studentansweredsurvey_answered_survey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentansweredsurvey_answered_survey_id_seq', 1, false);


--
-- Name: studentattendance_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentattendance_attendance_id_seq', 1, false);


--
-- Name: studentbalance_student_balance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentbalance_student_balance_id_seq', 1, false);


--
-- Name: studentclubevent_club_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentclubevent_club_event_id_seq', 1, false);


--
-- Name: studentclubs_student_club_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentclubs_student_club_id_seq', 1, false);


--
-- Name: studentcurriculum_student_curriculum_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentcurriculum_student_curriculum_id_seq', 1, false);


--
-- Name: studentschedule_student_curriculum_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentschedule_student_curriculum_id_seq', 1, false);


--
-- Name: studentstoadvise_students_to_advise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentstoadvise_students_to_advise_id_seq', 1, false);


--
-- Name: submission_submission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.submission_submission_id_seq', 1, false);


--
-- Name: surveys_surveys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.surveys_surveys_id_seq', 1, false);


--
-- Name: teacher_teacher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teacher_teacher_id_seq', 35, true);


--
-- Name: teachercourseplanning_teacher_course_planning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teachercourseplanning_teacher_course_planning_id_seq', 159, true);


--
-- Name: teacherschedule_teacher_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teacherschedule_teacher_schedule_id_seq', 1, false);


--
-- Name: teachersmajorplanning_teacher_major_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teachersmajorplanning_teacher_major_id_seq', 101, true);


--
-- Name: teachersschedule_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teachersschedule_schedule_id_seq', 81, true);


--
-- Name: transactioninformation_transaction_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactioninformation_transaction_info_id_seq', 1, false);


--
-- Name: user_signatures_user_signature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_signatures_user_signature_id_seq', 49, true);


--
-- Name: usercard_user_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usercard_user_card_id_seq', 1, false);


--
-- Name: userprofiles_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userprofiles_profile_id_seq', 1, false);


--
-- Name: announcement announcement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement
    ADD CONSTRAINT announcement_pkey PRIMARY KEY (announcement_id);


--
-- Name: auth_user auth_user_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_email_key UNIQUE (email);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (user_id);


--
-- Name: basecurriculum basecurriculum_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.basecurriculum
    ADD CONSTRAINT basecurriculum_pkey PRIMARY KEY (base_curriculum_id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (calendar_id);


--
-- Name: calendaraccess calendaraccess_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendaraccess
    ADD CONSTRAINT calendaraccess_pkey PRIMARY KEY (calendar_id);


--
-- Name: classrooms classroom_number_uq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classroom_number_uq UNIQUE (classroom_number);


--
-- Name: classroomproperties classroomproperties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classroomproperties
    ADD CONSTRAINT classroomproperties_pkey PRIMARY KEY (classroom_properties_id);


--
-- Name: classrooms classrooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_pkey PRIMARY KEY (classroom_id);


--
-- Name: clubmembers clubmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clubmembers
    ADD CONSTRAINT clubmembers_pkey PRIMARY KEY (club_member_id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (contract_id);


--
-- Name: courses course_name_unique_constraint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT course_name_unique_constraint UNIQUE (course_name);


--
-- Name: coursematerial coursematerial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursematerial
    ADD CONSTRAINT coursematerial_pkey PRIMARY KEY (course_material_id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (department_id);


--
-- Name: departmentsofeducation departmentsofeducation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departmentsofeducation
    ADD CONSTRAINT departmentsofeducation_pkey PRIMARY KEY (departments_of_education_id);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (grade_id);


--
-- Name: internalmessagingclub internalmessagingclub_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internalmessagingclub
    ADD CONSTRAINT internalmessagingclub_pkey PRIMARY KEY (internal_messaging_id);


--
-- Name: inventoryofteacher inventoryofteacher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventoryofteacher
    ADD CONSTRAINT inventoryofteacher_pkey PRIMARY KEY (inventory_of_teacher_id);


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_pkey PRIMARY KEY (invitation_id);


--
-- Name: auth_user login_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT login_name_key UNIQUE (login_name) INCLUDE (user_role, email);


--
-- Name: major major_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.major
    ADD CONSTRAINT major_name UNIQUE (major_name);


--
-- Name: major major_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.major
    ADD CONSTRAINT major_pkey PRIMARY KEY (major_id);


--
-- Name: notificationstudents notificationstudents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificationstudents
    ADD CONSTRAINT notificationstudents_pkey PRIMARY KEY (notification_students_id);


--
-- Name: paymentinformation paymentinformation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentinformation
    ADD CONSTRAINT paymentinformation_pkey PRIMARY KEY (payment_information_id);


--
-- Name: paymentlessonsselection paymentlessonsselection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentlessonsselection
    ADD CONSTRAINT paymentlessonsselection_pkey PRIMARY KEY (lesson_selection_id);


--
-- Name: teachersschedule pk_teachers_schedule_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersschedule
    ADD CONSTRAINT pk_teachers_schedule_id PRIMARY KEY (teachers_schedule_id);


--
-- Name: propertyofteacher propertyofteacher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propertyofteacher
    ADD CONSTRAINT propertyofteacher_pkey PRIMARY KEY (property_of_teacher_id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (rule_id);


--
-- Name: signedcontracts signedcontracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signedcontracts
    ADD CONSTRAINT signedcontracts_pkey PRIMARY KEY (singed_contract_id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: staff staff_staff_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_staff_code_key UNIQUE (staff_code);


--
-- Name: student student_enrollment_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_enrollment_number_key UNIQUE (enrollment_number);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (student_id);


--
-- Name: studentansweredsurvey studentansweredsurvey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentansweredsurvey
    ADD CONSTRAINT studentansweredsurvey_pkey PRIMARY KEY (answered_survey_id);


--
-- Name: studentattendance studentattendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentattendance
    ADD CONSTRAINT studentattendance_pkey PRIMARY KEY (attendance_id);


--
-- Name: studentbalance studentbalance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentbalance
    ADD CONSTRAINT studentbalance_pkey PRIMARY KEY (student_balance_id);


--
-- Name: studentclubevent studentclubevent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubevent
    ADD CONSTRAINT studentclubevent_pkey PRIMARY KEY (club_event_id);


--
-- Name: studentclubs studentclubs_club_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubs
    ADD CONSTRAINT studentclubs_club_code_key UNIQUE (club_code);


--
-- Name: studentclubs studentclubs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubs
    ADD CONSTRAINT studentclubs_pkey PRIMARY KEY (student_club_id);


--
-- Name: studentcurriculum studentcurriculum_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentcurriculum
    ADD CONSTRAINT studentcurriculum_pkey PRIMARY KEY (student_curriculum_id);


--
-- Name: studentschedule studentschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentschedule
    ADD CONSTRAINT studentschedule_pkey PRIMARY KEY (student_curriculum_id);


--
-- Name: studentstoadvise studentstoadvise_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentstoadvise
    ADD CONSTRAINT studentstoadvise_pkey PRIMARY KEY (students_to_advise_id);


--
-- Name: submission submission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_pkey PRIMARY KEY (submission_id);


--
-- Name: surveys surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_pkey PRIMARY KEY (surveys_id);


--
-- Name: teachersmajorplanning teacher_major_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersmajorplanning
    ADD CONSTRAINT teacher_major_id PRIMARY KEY (teacher_major_id);


--
-- Name: teacher teacher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher
    ADD CONSTRAINT teacher_pkey PRIMARY KEY (teacher_id);


--
-- Name: teacherscourseplanning teachercourseplanning_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT teachercourseplanning_pkey PRIMARY KEY (teacher_course_planning_id);


--
-- Name: teacherscourseplanning teachers_id_and_course_id_uq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT teachers_id_and_course_id_uq UNIQUE (teacher_id, major_id, course_id);


--
-- Name: teacherschedule teacherschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherschedule
    ADD CONSTRAINT teacherschedule_pkey PRIMARY KEY (teacher_schedule_id);


--
-- Name: transactioninformation transactioninformation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactioninformation
    ADD CONSTRAINT transactioninformation_pkey PRIMARY KEY (transaction_info_id);


--
-- Name: teachersmajorplanning unique_teacher_major; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersmajorplanning
    ADD CONSTRAINT unique_teacher_major UNIQUE (teacher_id, major_id);


--
-- Name: teachersschedule uq_classroom_time_teacher; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersschedule
    ADD CONSTRAINT uq_classroom_time_teacher UNIQUE (classroom_id, teacher_id, "time");


--
-- Name: student uq_student_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT uq_student_user_id UNIQUE (user_id);


--
-- Name: teacher uq_teacher_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher
    ADD CONSTRAINT uq_teacher_user_id UNIQUE (user_id);


--
-- Name: user_signatures uq_user_signatures_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_signatures
    ADD CONSTRAINT uq_user_signatures_user_id UNIQUE (user_id);


--
-- Name: usercard usercard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usercard
    ADD CONSTRAINT usercard_pkey PRIMARY KEY (user_card_id);


--
-- Name: userprofiles userprofiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userprofiles
    ADD CONSTRAINT userprofiles_pkey PRIMARY KEY (profile_id);


--
-- Name: announcement announcement_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement
    ADD CONSTRAINT announcement_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: announcement announcement_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement
    ADD CONSTRAINT announcement_major_id_fkey FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON DELETE CASCADE;


--
-- Name: announcement announcement_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement
    ADD CONSTRAINT announcement_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id);


--
-- Name: announcement announcement_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement
    ADD CONSTRAINT announcement_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: calendaraccess calendaraccess_calendar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendaraccess
    ADD CONSTRAINT calendaraccess_calendar_id_fkey FOREIGN KEY (calendar_id) REFERENCES public.calendar(calendar_id) ON DELETE CASCADE;


--
-- Name: calendaraccess calendaraccess_to_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendaraccess
    ADD CONSTRAINT calendaraccess_to_course_id_fkey FOREIGN KEY (to_course_id) REFERENCES public.courses(course_id);


--
-- Name: clubmembers clubmembers_student_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clubmembers
    ADD CONSTRAINT clubmembers_student_club_id_fkey FOREIGN KEY (student_club_id) REFERENCES public.studentclubs(student_club_id);


--
-- Name: clubmembers clubmembers_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clubmembers
    ADD CONSTRAINT clubmembers_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id);


--
-- Name: department departmentsofedu_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT departmentsofedu_fkey FOREIGN KEY (department_of_edu_id) REFERENCES public.departmentsofeducation(departments_of_education_id) NOT VALID;


--
-- Name: teacherschedule fk_classroom; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherschedule
    ADD CONSTRAINT fk_classroom FOREIGN KEY (classroom_id) REFERENCES public.classrooms(classroom_id);


--
-- Name: classroomproperties fk_classroom; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classroomproperties
    ADD CONSTRAINT fk_classroom FOREIGN KEY (classroom_id) REFERENCES public.classrooms(classroom_id);


--
-- Name: coursematerial fk_course; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursematerial
    ADD CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: basecurriculum fk_course; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.basecurriculum
    ADD CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: teacherscourseplanning fk_course; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: teacherschedule fk_course; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherschedule
    ADD CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: inventoryofteacher fk_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventoryofteacher
    ADD CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- Name: teacherscourseplanning fk_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- Name: classrooms fk_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES public.departmentsofeducation(departments_of_education_id);


--
-- Name: teacherschedule fk_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherschedule
    ADD CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES public.department(department_id) ON DELETE CASCADE;


--
-- Name: teacher fk_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher
    ADD CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES public.department(department_id) NOT VALID;


--
-- Name: teachersmajorplanning fk_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersmajorplanning
    ADD CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- Name: major fk_department_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.major
    ADD CONSTRAINT fk_department_id FOREIGN KEY (department_id) REFERENCES public.department(department_id) NOT VALID;


--
-- Name: major fk_departments_of_edu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.major
    ADD CONSTRAINT fk_departments_of_edu FOREIGN KEY (department_of_edu_id) REFERENCES public.department(department_id);


--
-- Name: teacher fk_departments_of_edu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher
    ADD CONSTRAINT fk_departments_of_edu FOREIGN KEY (departments_of_education_id) REFERENCES public.departmentsofeducation(departments_of_education_id) NOT VALID;


--
-- Name: teacherscourseplanning fk_departments_of_edu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT fk_departments_of_edu FOREIGN KEY (department_of_edu_id) REFERENCES public.departmentsofeducation(departments_of_education_id) NOT VALID;


--
-- Name: teachersmajorplanning fk_departments_of_edu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersmajorplanning
    ADD CONSTRAINT fk_departments_of_edu FOREIGN KEY (department_of_educations_id) REFERENCES public.departmentsofeducation(departments_of_education_id);


--
-- Name: courses fk_major; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT fk_major FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON DELETE CASCADE;


--
-- Name: coursematerial fk_major; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursematerial
    ADD CONSTRAINT fk_major FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON DELETE CASCADE;


--
-- Name: basecurriculum fk_major; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.basecurriculum
    ADD CONSTRAINT fk_major FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON DELETE CASCADE;


--
-- Name: student fk_major; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT fk_major FOREIGN KEY (major_id) REFERENCES public.major(major_id);


--
-- Name: teachersschedule fk_major; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersschedule
    ADD CONSTRAINT fk_major FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: student fk_student_club; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT fk_student_club FOREIGN KEY (student_club_id) REFERENCES public.studentclubs(student_club_id);


--
-- Name: student fk_student_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT fk_student_department FOREIGN KEY (department_id) REFERENCES public.department(department_id) NOT VALID;


--
-- Name: coursematerial fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursematerial
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) ON DELETE CASCADE;


--
-- Name: calendar fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) ON DELETE CASCADE;


--
-- Name: inventoryofteacher fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventoryofteacher
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) ON DELETE CASCADE;


--
-- Name: teacherscourseplanning fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) ON DELETE CASCADE;


--
-- Name: teacherschedule fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherschedule
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: teachersmajorplanning fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersmajorplanning
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) ON DELETE CASCADE;


--
-- Name: teachersschedule fk_teacher; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersschedule
    ADD CONSTRAINT fk_teacher FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) NOT VALID;


--
-- Name: teacherscourseplanning fk_teacher_major; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacherscourseplanning
    ADD CONSTRAINT fk_teacher_major FOREIGN KEY (teacher_major_id) REFERENCES public.teachersmajorplanning(teacher_major_id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: teachersschedule fk_teachers_course_planning; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachersschedule
    ADD CONSTRAINT fk_teachers_course_planning FOREIGN KEY (course_planning_id) REFERENCES public.teacherscourseplanning(teacher_course_planning_id) NOT VALID;


--
-- Name: teacher fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id) ON DELETE CASCADE;


--
-- Name: usercard fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usercard
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id) ON DELETE CASCADE;


--
-- Name: userprofiles fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userprofiles
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id);


--
-- Name: student fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id) ON DELETE CASCADE;


--
-- Name: user_signatures fk_user_signatures; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_signatures
    ADD CONSTRAINT fk_user_signatures FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id) ON DELETE CASCADE NOT VALID;


--
-- Name: grades grades_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: grades grades_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: internalmessagingclub internalmessagingclub_club_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internalmessagingclub
    ADD CONSTRAINT internalmessagingclub_club_member_id_fkey FOREIGN KEY (club_member_id) REFERENCES public.clubmembers(club_member_id) ON DELETE CASCADE;


--
-- Name: internalmessagingclub internalmessagingclub_mention_someone_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internalmessagingclub
    ADD CONSTRAINT internalmessagingclub_mention_someone_fkey FOREIGN KEY (mention_someone) REFERENCES public.clubmembers(club_member_id) ON DELETE CASCADE;


--
-- Name: internalmessagingclub internalmessagingclub_replied_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internalmessagingclub
    ADD CONSTRAINT internalmessagingclub_replied_to_fkey FOREIGN KEY (replied_to) REFERENCES public.internalmessagingclub(internal_messaging_id) ON DELETE CASCADE;


--
-- Name: internalmessagingclub internalmessagingclub_student_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internalmessagingclub
    ADD CONSTRAINT internalmessagingclub_student_club_id_fkey FOREIGN KEY (student_club_id) REFERENCES public.studentclubs(student_club_id) ON DELETE CASCADE;


--
-- Name: internalmessagingclub internalmessagingclub_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internalmessagingclub
    ADD CONSTRAINT internalmessagingclub_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: invitations invitations_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: invitations invitations_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_major_id_fkey FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON DELETE CASCADE;


--
-- Name: invitations invitations_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: invitations invitations_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: notificationstudents notificationstudents_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificationstudents
    ADD CONSTRAINT notificationstudents_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: notificationstudents notificationstudents_course_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificationstudents
    ADD CONSTRAINT notificationstudents_course_material_id_fkey FOREIGN KEY (course_material_id) REFERENCES public.coursematerial(course_material_id);


--
-- Name: notificationstudents notificationstudents_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificationstudents
    ADD CONSTRAINT notificationstudents_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: notificationstudents notificationstudents_to_student_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificationstudents
    ADD CONSTRAINT notificationstudents_to_student_fkey FOREIGN KEY (to_student) REFERENCES public.student(student_id);


--
-- Name: paymentinformation paymentinformation_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentinformation
    ADD CONSTRAINT paymentinformation_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: paymentlessonsselection paymentlessonsselection_payment_information_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentlessonsselection
    ADD CONSTRAINT paymentlessonsselection_payment_information_id_fkey FOREIGN KEY (payment_information_id) REFERENCES public.paymentinformation(payment_information_id);


--
-- Name: paymentlessonsselection paymentlessonsselection_student_curriculum_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentlessonsselection
    ADD CONSTRAINT paymentlessonsselection_student_curriculum_id_fkey FOREIGN KEY (student_curriculum_id) REFERENCES public.studentcurriculum(student_curriculum_id);


--
-- Name: paymentlessonsselection paymentlessonsselection_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paymentlessonsselection
    ADD CONSTRAINT paymentlessonsselection_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: propertyofteacher propertyofteacher_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propertyofteacher
    ADD CONSTRAINT propertyofteacher_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- Name: propertyofteacher propertyofteacher_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propertyofteacher
    ADD CONSTRAINT propertyofteacher_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id) ON DELETE CASCADE;


--
-- Name: signedcontracts signedcontracts_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signedcontracts
    ADD CONSTRAINT signedcontracts_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(contract_id) ON DELETE CASCADE;


--
-- Name: signedcontracts signedcontracts_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signedcontracts
    ADD CONSTRAINT signedcontracts_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: signedcontracts signedcontracts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signedcontracts
    ADD CONSTRAINT signedcontracts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id) ON DELETE CASCADE;


--
-- Name: staff staff_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- Name: staff staff_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_user(user_id) ON DELETE CASCADE;


--
-- Name: studentansweredsurvey studentansweredsurvey_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentansweredsurvey
    ADD CONSTRAINT studentansweredsurvey_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: studentansweredsurvey studentansweredsurvey_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentansweredsurvey
    ADD CONSTRAINT studentansweredsurvey_survey_id_fkey FOREIGN KEY (survey_id) REFERENCES public.surveys(surveys_id);


--
-- Name: studentattendance studentattendance_course_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentattendance
    ADD CONSTRAINT studentattendance_course_material_id_fkey FOREIGN KEY (course_material_id) REFERENCES public.coursematerial(course_material_id) ON DELETE CASCADE;


--
-- Name: studentattendance studentattendance_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentattendance
    ADD CONSTRAINT studentattendance_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: studentbalance studentbalance_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentbalance
    ADD CONSTRAINT studentbalance_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: studentbalance studentbalance_transaction_info_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentbalance
    ADD CONSTRAINT studentbalance_transaction_info_id_fkey FOREIGN KEY (transaction_info_id) REFERENCES public.transactioninformation(transaction_info_id) ON DELETE CASCADE;


--
-- Name: studentclubevent studentclubevent_student_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubevent
    ADD CONSTRAINT studentclubevent_student_club_id_fkey FOREIGN KEY (student_club_id) REFERENCES public.studentclubs(student_club_id) ON DELETE CASCADE;


--
-- Name: studentclubs studentclubs_club_advisor_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubs
    ADD CONSTRAINT studentclubs_club_advisor_teacher_id_fkey FOREIGN KEY (club_advisor_teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: studentclubs studentclubs_club_assistant_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubs
    ADD CONSTRAINT studentclubs_club_assistant_leader_id_fkey FOREIGN KEY (club_assistant_leader_id) REFERENCES public.auth_user(user_id);


--
-- Name: studentclubs studentclubs_club_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubs
    ADD CONSTRAINT studentclubs_club_major_id_fkey FOREIGN KEY (club_major_id) REFERENCES public.major(major_id);


--
-- Name: studentclubs studentclubs_club_primary_leader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentclubs
    ADD CONSTRAINT studentclubs_club_primary_leader_id_fkey FOREIGN KEY (club_primary_leader_id) REFERENCES public.auth_user(user_id);


--
-- Name: studentcurriculum studentcurriculum_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentcurriculum
    ADD CONSTRAINT studentcurriculum_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: studentcurriculum studentcurriculum_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentcurriculum
    ADD CONSTRAINT studentcurriculum_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: studentschedule studentschedule_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentschedule
    ADD CONSTRAINT studentschedule_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id) ON DELETE CASCADE;


--
-- Name: studentschedule studentschedule_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentschedule
    ADD CONSTRAINT studentschedule_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: studentstoadvise studentstoadvise_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentstoadvise
    ADD CONSTRAINT studentstoadvise_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(course_id);


--
-- Name: studentstoadvise studentstoadvise_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentstoadvise
    ADD CONSTRAINT studentstoadvise_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.department(department_id);


--
-- Name: studentstoadvise studentstoadvise_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentstoadvise
    ADD CONSTRAINT studentstoadvise_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: studentstoadvise studentstoadvise_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentstoadvise
    ADD CONSTRAINT studentstoadvise_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: submission submission_course_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_course_material_id_fkey FOREIGN KEY (course_material_id) REFERENCES public.coursematerial(course_material_id) ON DELETE CASCADE;


--
-- Name: submission submission_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: submission submission_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teacher(teacher_id);


--
-- Name: surveys surveys_major_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_major_id_fkey FOREIGN KEY (major_id) REFERENCES public.major(major_id) ON DELETE CASCADE;


--
-- Name: surveys surveys_to_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_to_student_id_fkey FOREIGN KEY (to_student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- Name: transactioninformation transactioninformation_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactioninformation
    ADD CONSTRAINT transactioninformation_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(student_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

